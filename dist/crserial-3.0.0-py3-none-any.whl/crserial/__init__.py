import ctypes, os
current_dir = os.path.dirname(os.path.abspath(__file__))
lib_path = os.path.join(current_dir, "_crserial.so")
_lib = ctypes.CDLL(lib_path)
_lib.check_and_hash.argtypes = [ctypes.c_char_p]
_lib.check_and_hash.restype = ctypes.c_char_p

def serial(key=None):
    if key is None: return "Not Access X_X"
    return _lib.check_and_hash(key.encode('utf-8')).decode('utf-8')


