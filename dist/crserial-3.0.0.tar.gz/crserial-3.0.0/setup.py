from setuptools import setup, find_packages

setup(
    name="crserial",
    version="3.0.0",
    packages=find_packages(),
    author="crdex",
    author_email="crdexaymanambaby@gmail.com",
    description="Secure device serial extraction library powered by C.",
    long_description="The most powerful library for extracting your device's serial number without root access. Built with a high-performance C native core for security and speed. Compatible with Python emulators and based on your device's camera serial number.",
    package_data={
        'crserial': ['_crserial.so'],
    },
    include_package_data=True,
    zip_safe=False, 
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
    python_requires=">=3.8",
)
